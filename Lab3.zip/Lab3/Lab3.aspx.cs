﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Lab3_Lab3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        int bonus = Convert.ToInt32(TextBox1.Text);
        const int NEW_YORK_AMOUNT = 1000;
        const int NEW_YORK_AND_DEBT_AMOUNT = 5000;
        const int EUROPE_AMOUNT = 10000;
        
        if (bonus < NEW_YORK_AND_DEBT_AMOUNT & bonus >= NEW_YORK_AMOUNT)
        {
            Label1.Text = "We're going to New York for a week.";
        }
        else if (bonus < EUROPE_AMOUNT && bonus >= NEW_YORK_AND_DEBT_AMOUNT)
        {
            Label1.Text = "We're going to pay off some debt AND go to New York.";
        }
        else if (bonus >= EUROPE_AMOUNT)
        {
            Label1.Text = "We're putting a downpayment on a new car and going to Europe.";
        }
        else
        {
            Label1.Text = "We're staying home because we're paying off a little student debt.";
        }
    }
}