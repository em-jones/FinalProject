﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Lab4_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Label1.Text = "";
        foreach(ListItem item in CheckBoxList1.Items){
            if (item.Selected == true)
            {
                Label1.Text += item.Text + "</br>";
            }
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        int sum = 0;
        if (Convert.ToInt32(TextBox1.Text) < Convert.ToInt32(TextBox2.Text))
        {
            for (int i = Convert.ToInt32(TextBox1.Text); i <= Convert.ToInt32(TextBox2.Text); i++)
            { sum += i; }
            Label2.Text = "The totals is " + Convert.ToString(sum);
        }
        else
        {
            Label2.Text = "Please enter an integer in the <u>second box</u> that is <u>larger</u> than the integer in the first box.";

        }
        //boxAdditionLoop loop = new boxAdditionLoop(TextBox1.Text, TextBox2.Text);

        //Label2.Text = loop.perform();
        
    }
}